exports.handler = async (event) => {
  // V2_0 Pre Token Generation Lambda
  // Adds cognito:groups to ID token claims for OIDC
  console.log('Event:', JSON.stringify(event, null, 2));
        
  const groups = event.request.groupConfiguration.groupsToOverride || [];
        
  // Return the response with groups claim added to ID token
  event.response = {
    claimsAndScopeOverrideDetails: {
      idTokenGeneration: {
        claimsToAddOrOverride: {
          "cognito:groups": JSON.stringify(groups)
        }
      },
      accessTokenGeneration: {
        claimsToAddOrOverride: {
          "cognito:groups": JSON.stringify(groups)
        }
      }
    }
  };
        
  console.log('Response:', JSON.stringify(event.response, null, 2));
  return event;
};
